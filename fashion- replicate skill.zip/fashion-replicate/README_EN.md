# Fashion Replicate — AI Video Outfit-Change Replication Skill

A skill (SKILL.md) that teaches an AI creative agent to reliably replicate **outfit-change short videos**.

Give it a source video (fashion transition, creative outfit-swap, or lifestyle showcase) plus a character reference image and garment images. The output replicates the source's camera movement, transition rhythm, and outfit-change timing — while keeping **your** character, garments, and scene. It never borrows the original video's face.

## The Problems It Solves

Asking a video model to "replicate this video" directly runs into four recurring failures:

| Failure Mode | Symptom | Countermeasure |
|---|---|---|
| Temporal structure loss | Outfit changes fire at wrong moments; transition rhythm collapses | Depth-video carries motion & trajectories; occlusion-coupled swap timing written explicitly into prompts |
| Identity drift | Face changes after transitions; source character's look bleeds in | Character anchor image + full-length identity declaration; source-face borrowing prohibited |
| Garment quality degradation | Painterly texture, flat-lay copying, no fabric physics | Conditionally-triggered quality still frames + positive physical description of fabric behavior |
| Prop behavior chaos | Props gain unscripted actions; pets morph into blobs | Per-prop anchor confirmation gate + behavior bound to the source video |

## Workflow at a Glance

Shot breakdown → Input diagnosis (anchor confirmation / impact warnings) → Conditional still frames → Route selection → Generation → Acceptance checks

Three generation routes:

- **Route B (Verified)** — Depth video + single-pass generation. For continuous-motion, occlusion-transition outfit videos under 15 seconds. The core proven path, validated with multiple success/failure comparisons.
- **Route A (Unverified)** — Segment-then-stitch when cut points are clean. Never tested.
- **Route C (Unverified)** — Whole-source low-cost preview pass. Never tested.

## What Makes This Skill Different: Confidence Labels

In most skills, every rule looks equally trustworthy — a mix of tested conclusions and plausible inferences. This skill tags every rule with one of four labels:

- `Verified` — backed by both a success and a failure case
- `Partially verified` — mechanism works, boundaries unknown
- `Unverified` — inference; must be probed at low cost before real use
- `Discontinued` — tested and failed; kept as a counter-example

Case in point: "spatio-temporal trajectory-locating replacement" was the most detailed rule in this skill. It failed both field tests. It is now labeled `Discontinued` and rewritten as a keyframe-based alternative. **Detail level says nothing about validity — the most expensive lesson of this project.**

## Requirements

- An AI agent environment that supports loading skills (SKILL.md)
- A depth-video capability (for camera-motion and action transfer)
- Inputs: source video, character reference image (clear, unobstructed face), garment images (real worn photos preferred over flat-lay)
- Reference image budget: 4 per generation preferred, 8 absolute max

## Known Limitations (Honest Disclosure)

- Only Route B has been battle-tested. Route A, Route C, and the three-signal cut-point detection have never been run
- Local edit replacement (inserting an object the source doesn't have) failed twice on fast models; the keyframe alternative is verified only at the image layer so far
- 480p fast models cap garment quality — use a full model at 1080p
- Not covered: multi-subject complex interaction, precise camera-following, >15s stitched outputs

## How to Contribute

This skill is currently "one proven path + several unproven ones." Contributions welcome:

1. **Verify the unverified**: run Route A/C or signal-based cut detection on your own project and report back — failures are as valuable as successes (include model & parameters)
2. **Expand the failure boundary**: re-test `Discontinued` rules on different models/settings. "Fails on fast models" does not mean "fails forever"
3. **Report new failure modes**: hit something the workflow doesn't cover? Open an issue with your scenario

## Repository Structure

```
fashion-replicate/
└── SKILL.md    # The skill itself (confidence-labeled edition)
```

## License

MIT
